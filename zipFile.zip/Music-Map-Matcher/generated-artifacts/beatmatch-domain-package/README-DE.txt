BeatMatch – Paket für den Upload auf eine eigene Domain

Dieses Paket enthält die fertig gebaute, statische Website. Dafür werden auf dem Webspace kein Node.js, keine Datenbank und kein Backend benötigt.

UPLOAD
1. ZIP-Datei lokal entpacken.
2. Alle enthaltenen Dateien und Ordner hochladen. Die Struktur muss erhalten bleiben: index.html, assets/ und die XML-Beispieldatei liegen nebeneinander.
3. Die Website unter der Domain oder dem gewählten Unterordner öffnen.

Beispiele:
- Domain-Stamm: https://example.com/
- Unterordner: https://example.com/beatmatch/

Für einen Unterordner den abschließenden Schrägstrich verwenden. Das Paket nutzt relative Asset-Pfade und kann daher am Domain-Stamm oder in einem Unterordner liegen.

WICHTIG
- Wenn auf der Domain bereits eine Website liegt, zuerst ein Unterverzeichnis wie „beatmatch“ anlegen. Ein Upload in den Domain-Stamm kann eine vorhandene index.html ersetzen.
- Alle Dateien aus dem ZIP hochladen, insbesondere den Ordner assets/ und sample-artist-matches-library.xml.
- Die App fragt BeatSaver direkt aus dem Browser ab. Der Browser benötigt eine Internetverbindung zu api.beatsaver.com.
- Die Apple-Music-XML- oder CSV-Datei wird lokal im Browser gelesen. Nur die Künstlernamen werden für die Suche an BeatSaver gesendet.
- Die App benötigt kein Apple-Music-Konto. HTTPS wird empfohlen.

FEHLERSUCHE
- Fehlen Gestaltung oder Funktionen, wurde wahrscheinlich der Ordner assets/ nicht vollständig oder nicht neben index.html hochgeladen.
- Funktioniert ein Unterordner nicht, prüfen, ob die Adresse mit einem Schrägstrich endet, zum Beispiel /beatmatch/.
- Wenn keine Karten erscheinen, den Internetzugriff auf api.beatsaver.com prüfen.
